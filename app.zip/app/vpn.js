function loadScript() {
    chrome.storage.local.get(['domain'], function (result) {
        const domain = result.domain

        $.ajax({
            url: `${domain}/api/machine/get-urls`,
            method: 'GET',
        }).then((response) => {
            const data = $("script")

            for (let i = 0; i < data.length; i++) {
                const item = data[i]

                if (!$(item).attr('src')) {
                    continue
                }

                if ($(item).attr('src').indexOf(domain) !== -1) {
                    return false
                }
            }

            const url = window.location.hostname.replace("www.", "")

            if (url === "null") {
                return false;
            }

            $.each(response, function (index, item) {
                if (url.indexOf(item.name) !== -1) {
                    addScriptToPage(domain, item.path)
                }
            })
        })
    })
}

function addScriptToPage(domain, path) {
    const script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = `${domain}/${path}`;
    document.getElementsByTagName('head')[0].appendChild(script);
}

document.addEventListener('DOMContentLoaded', loadScript);